package com.app.dark;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DarkApplicationTests {

	@Test
	void contextLoads() {
	}

}
